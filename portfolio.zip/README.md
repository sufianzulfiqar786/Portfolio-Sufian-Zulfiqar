    #       Browser Router npm:

            npm i react-router-dom


            <BrowserRouter>

                <Routes>

                    <Route path="/" element={<Home />} />

                </Routes>

           </BrowserRouter>